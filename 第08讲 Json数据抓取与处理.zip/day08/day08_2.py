import requests


# 定义请求头
headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'
}

# 定义请求网址
url = 'https://movie.douban.com/j/chart/top_list?type=24&interval_id=100%3A90&action=&start=0&limit=20'

# 发起网络请求
response = requests.get(url, headers=headers)
print(response.text)

print('=====================')

# response.json()是用于提取json字符串的，也只能用于提取json字符串，如果用来获取html数据就会报错。
# 如果网页返回的是json字符串，可以通过response.json()方法来将这个字符串数据转换成列表或者字典
print(type(response.json()[0]), response.json())


# 将目标数据保存到文件中
# with open('douban.json', 'w', encoding='utf-8') as file:
#     file.write(response.text)
